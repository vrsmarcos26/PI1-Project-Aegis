/* ==================================================================
   ARQUIVO DE SCRIPT PRINCIPAL (script.js)
   Controla a interatividade do dashboard:
   1. Alternador de Tema (Dark/Light)
   2. Carregamento de Dados (Fetch) dos arquivos JSON
   3. Lógica de Filtro de Datas (30d, 90d, 1ano)
   4. Renderização de Gráficos (Chart.js)
   ================================================================== */

// --- VARIÁVEIS GLOBAIS PARA GRÁFICOS ---
let meuGraficoDonut = null;
let meuGraficoLinha = null;
let meuGraficoSetores = null;
let meuGraficoPaises = null;
let meuGraficoTiposVuln = null;

// --- BANCOS DE DADOS LOCAIS (Na Memória do Navegador) ---
// Estes arrays guardam os dados brutos carregados dos JSONs
let DADOS_COMPLETOS_CVE = []; 
let DADOS_COMPLETOS_HIBP = [];
let DADOS_COMPLETOS_OTX = []; 
let DADOS_COMPLETOS_PAISES = []; // NOVO: Banco de dados de países

// Idioma Atual (Padrão: PT-BR)
let idiomaAtual = localStorage.getItem('lang') || 'pt_br';

document.addEventListener('DOMContentLoaded', () => {
    
    const themeToggle = document.getElementById('theme-toggle');
    const periodFilter = document.getElementById('period-filter');
    const body = document.body;

    // 1. Aplicar Idioma Inicial
    mudarIdioma(idiomaAtual);

    // --- Lógica do Tema ---
    const aplicarTema = (tema) => {
        body.classList.toggle('dark-theme', tema === 'dark');
        // Atualiza o texto do botão baseado no idioma atual
        atualizarBotaoTema(tema);
        
        // Recarregar gráficos se estiver na página principal
        if (document.getElementById('donutChart')) {
            recriarGraficos();
        }
    };

    const temaSalvo = localStorage.getItem('theme') || 'light';
    body.classList.toggle('dark-theme', temaSalvo === 'dark');
    atualizarBotaoTema(temaSalvo);

    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const novoTema = body.classList.contains('dark-theme') ? 'light' : 'dark';
            aplicarTema(novoTema);
            localStorage.setItem('theme', novoTema);
        });
    }

    // Se existir filtro de período na página
    if (periodFilter) {
        periodFilter.addEventListener('change', (e) => {
            filtrarEAtualizarDashboard(e.target.value);
        });
    }
    
    // --- Carga Inicial (Só se for a página do dashboard) ---
    if (document.querySelector('.kpi-grid')) {
        carregarDadosCVE(); 
        carregarDadosHIBP();
        carregarDadosOTX();
        carregarDadosPaises();
    }
});

/// --- FUNÇÕES DE IDIOMA (ATUALIZADA) ---

function mudarIdioma(lang) {
    idiomaAtual = lang;
    localStorage.setItem('lang', lang);
    if (typeof langConfig === 'undefined') return;
    const t = langConfig[lang];
    
    // Sidebar (Comum)
    setText('lbl-sidebar-dashboard', t.sidebar.dashboard);
    setText('lbl-sidebar-analysis', t.sidebar.analysis);
    setText('lbl-sidebar-leaks', t.sidebar.leaks);
    setText('lbl-sidebar-reports', t.sidebar.reports);
    setText('lbl-sidebar-settings', t.sidebar.settings);
    setText('lbl-sidebar-collaborators', t.sidebar.collaborators);
    
    // Se estiver no DASHBOARD PRINCIPAL
    if (document.getElementById('lbl-header-title')) {
        setText('lbl-header-title', t.header.title);
        setText('lbl-period-30d', t.header.period.d30);
        setText('lbl-period-90d', t.header.period.d90);
        setText('lbl-period-1y', t.header.period.y1);
        
        setText('lbl-kpi-vulns', t.kpis.vulns);
        setText('lbl-kpi-leaks', t.kpis.leaks);
        setText('lbl-kpi-threat', t.kpis.threat);
        setText('lbl-kpi-sector', t.kpis.sector);
        
        setText('lbl-chart-trend', t.charts.trend);
        setText('lbl-chart-severity', t.charts.severity);
        setText('lbl-chart-sectors', t.charts.sectors);
        setText('lbl-chart-countries', t.charts.countries);
        setText('lbl-chart-types', t.charts.types);
        
        setText('lbl-table-title', t.table.title);
        setText('lbl-col-company', t.table.cols.company);
        setText('lbl-col-sector', t.table.cols.sector);
        setText('lbl-col-accounts', t.table.cols.accounts);
        setText('lbl-table-loading', t.table.loading);
        
        recriarGraficos();
    }
    
    // Se estiver na página de RELATÓRIOS
    if (document.getElementById('lbl-reports-title')) {
        const r = t.reportsPage;
        setText('lbl-reports-title', r.title);
        
        // Aviso HTML
        const noticeEl = document.getElementById('lbl-data-notice');
        if(noticeEl) noticeEl.innerHTML = r.notice;
        
        // Feeds
        setText('lbl-otx-title', r.feeds.otx.title);
        setText('lbl-otx-desc', r.feeds.otx.desc);
        setText('th-otx-date', r.feeds.otx.cols.date);
        setText('th-otx-threats', r.feeds.otx.cols.threats);
        setText('th-otx-countries', r.feeds.otx.cols.countries);
        
        setText('lbl-hibp-title', r.feeds.hibp.title);
        setText('th-hibp-date', r.feeds.hibp.cols.date);
        setText('th-hibp-service', r.feeds.hibp.cols.service);
        setText('th-hibp-impact', r.feeds.hibp.cols.impact);
        
        setText('lbl-nvd-title', r.feeds.nvd.title);
        setText('th-nvd-id', r.feeds.nvd.cols.id);
        setText('th-nvd-date', r.feeds.nvd.cols.date);
        setText('th-nvd-type', r.feeds.nvd.cols.type);
        
        // Docs
        setText('lbl-docs-title', r.docs.title);
        setText('lbl-docs-desc', r.docs.desc);
        setText('lbl-doc-vision-title', r.docs.links.vision.title);
        setText('lbl-doc-vision-sub', r.docs.links.vision.sub);
        setText('lbl-doc-plan-title', r.docs.links.plan.title);
        setText('lbl-doc-plan-sub', r.docs.links.plan.sub);
        setText('lbl-doc-arch-title', r.docs.links.arch.title);
        setText('lbl-doc-arch-sub', r.docs.links.arch.sub);
        setText('lbl-doc-repo-title', r.docs.links.repo.title);
        setText('lbl-doc-repo-sub', r.docs.links.repo.sub);

        // Filtro Select
        const sel = document.getElementById('filter-reports');
        if(sel) {
            sel.options[0].text = r.filters.all;
            sel.options[1].text = r.filters.otx;
            sel.options[2].text = r.filters.hibp;
            sel.options[3].text = r.filters.nvd;
        }
    }

    // --- NOVO: Página de Fontes ---
    if (document.getElementById('lbl-sources-title')) {
        const s = t.sourcesPage;
        setText('lbl-sources-title', s.title);
        
        // Botões comuns
        document.querySelectorAll('.lbl-btn-visit').forEach(btn => btn.innerText = s.btnVisit);
        
        // NVD
        setText('lbl-src-nvd-desc', s.nvd.desc);
        setText('lbl-src-nvd-detail', s.nvd.detail);
        setText('lbl-src-nvd-tag1', s.nvd.tags[0]);
        setText('lbl-src-nvd-tag2', s.nvd.tags[1]);

        // HIBP
        setText('lbl-src-hibp-desc', s.hibp.desc);
        setText('lbl-src-hibp-detail', s.hibp.detail);
        setText('lbl-src-hibp-tag1', s.hibp.tags[0]);
        setText('lbl-src-hibp-tag2', s.hibp.tags[1]);

        // OTX
        setText('lbl-src-otx-desc', s.otx.desc);
        setText('lbl-src-otx-detail', s.otx.detail);
        setText('lbl-src-otx-tag1', s.otx.tags[0]);
        setText('lbl-src-otx-tag2', s.otx.tags[1]);

        // Abuse
        setText('lbl-src-abuse-desc', s.abuse.desc);
        setText('lbl-src-abuse-detail', s.abuse.detail);
        setText('lbl-src-abuse-tag1', s.abuse.tags[0]);
        setText('lbl-src-abuse-tag2', s.abuse.tags[1]);
    }

    // Atualiza classes dos botões
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.innerText.toLowerCase() === lang.split('_')[0]) {
            btn.classList.add('active');
        }
    });
    
    // Atualiza botão de tema
    const temaAtual = document.body.classList.contains('dark-theme') ? 'dark' : 'light';
    atualizarBotaoTema(temaAtual);

    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.innerText.toLowerCase() === lang.split('_')[0]) {
            btn.classList.add('active');
        }
    });
}

function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.innerText = text;
}

function atualizarBotaoTema(tema) {
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.innerText = langConfig[idiomaAtual].header.themeBtn[tema];
    }
}

function recriarGraficos() {
    if (meuGraficoDonut) meuGraficoDonut.destroy();
    if (meuGraficoLinha) meuGraficoLinha.destroy();
    if (meuGraficoSetores) meuGraficoSetores.destroy();
    if (meuGraficoPaises) meuGraficoPaises.destroy();
    if (meuGraficoTiposVuln) meuGraficoTiposVuln.destroy();
    
    const pFilter = document.getElementById('period-filter');
    if (pFilter) {
        const periodo = pFilter.value;
        filtrarEAtualizarDashboard(periodo);
        carregarDadosOTX();
        carregarDadosPaises();
    }
}

/**
 * PASSO 1: Funções de Carregamento (Fetch)
 * Elas baixam o JSON e salvam nas variáveis globais DADOS_COMPLETOS_X
 */

async function carregarDadosCVE() {
    try {
        const response = await fetch(`cve_kpis.json?v=${new Date().getTime()}`);
        if (!response.ok) throw new Error(`Erro ao carregar cve_kpis.json`);
        
        const data = await response.json(); 
        
        DADOS_COMPLETOS_CVE = data.map(item => {
            // Converter string de data para Objeto Date
            item.data_publicacao = new Date(item.data_publicacao + "T00:00:00"); 
            return item;
        });
        
        console.log(`Sucesso! Carregados ${DADOS_COMPLETOS_CVE.length} registros de CVEs.`);
        atualizarTelaSePossivel();
    } catch (e) { console.error("Erro CVE:", e); }
}

async function carregarDadosHIBP() {
    try {
        const response = await fetch(`hibp_kpis.json?v=${new Date().getTime()}`);
        if (!response.ok) throw new Error(`Erro ao carregar hibp_kpis.json`);
        const data = await response.json();
        
        // Verifica se o JSON é uma lista direta ou um objeto antigo
        let listaBruta = Array.isArray(data) ? data : (data.vazamentos_recentes_tabela || []);

        DADOS_COMPLETOS_HIBP = listaBruta.map(item => {
            if (item.data_vazamento) {
                // Tratamento para datas YYYY-MM-DD
                const dataStr = item.data_vazamento.includes('T') ? item.data_vazamento : item.data_vazamento + "T00:00:00";
                item.data_vazamento = new Date(dataStr);
            }
            return item;
        });
        
        console.log(`Sucesso! Carregados ${DADOS_COMPLETOS_HIBP.length} registros de Vazamentos.`);
        atualizarTelaSePossivel();
    } catch (e) { console.error("Erro HIBP:", e); }
}

async function carregarDadosOTX() {
    try {
        const response = await fetch(`otx_kpis.json?v=${new Date().getTime()}`);
        if (!response.ok) throw new Error(`Erro ao carregar otx_kpis.json`);
        const data = await response.json();
        
        DADOS_COMPLETOS_OTX = data.map(item => {
            if (item.data_criacao) {
                const dataStr = item.data_criacao.includes('T') ? item.data_criacao : item.data_criacao + "T00:00:00";
                item.data_criacao = new Date(dataStr);
            }
            return item;
        });
        
        console.log(`Sucesso! Carregados ${DADOS_COMPLETOS_OTX.length} pulsos OTX.`);
        atualizarTelaSePossivel();
    } catch (e) { console.error("Erro OTX:", e); }
}

async function carregarDadosPaises() {
    try {
        const response = await fetch(`paises_kpis.json?v=${new Date().getTime()}`);
        if (!response.ok) throw new Error(`Erro ao carregar paises_kpis.json`);
        const data = await response.json();

        // Agora esperamos uma LISTA bruta de objetos {pais, data_report}
        DADOS_COMPLETOS_PAISES = data.map(item => {
            if (item.data_report && item.data_report !== "N/A") {
                const dataStr = item.data_report.includes('T') ? item.data_report : item.data_report + "T00:00:00";
                item.data_report = new Date(dataStr);
            }
            return item;
        });
        
        // Renderiza direto, usando o idioma atual para a label
        renderizarGraficoPaises(DADOS_COMPLETOS_PAISES);
    } catch (e) { console.error("Erro Países:", e); }
}

// Função auxiliar para chamar o filtro apenas quando tivermos dados
function atualizarTelaSePossivel() {
    const periodoElem = document.getElementById('period-filter');
    if (periodoElem) filtrarEAtualizarDashboard(periodoElem.value);
}

function renderizarGraficoPaises(dadosBrutos) {
    if (!dadosBrutos || dadosBrutos.length === 0) return;
    
    // Lógica simples para pegar top 5 países da lista bruta
    const contPaises = {};
    dadosBrutos.forEach(item => {
        if (item.pais) contPaises[item.pais] = (contPaises[item.pais] || 0) + 1;
    });
    const topPaises = Object.entries(contPaises).sort((a, b) => b[1] - a[1]).slice(0, 5).reduce((r, [k, v]) => ({ ...r, [k]: v }), {});
    
    // Label traduzida
    const labelChart = langConfig[idiomaAtual].charts.countries;
    renderizarGraficoBarras('paisesChart', meuGraficoPaises, topPaises, labelChart);
}


/**
 * PASSO 2: A MÁGICA DO FILTRO (Central de Controle)
 * Recebe '30d', '90d' ou '1ano' e recalcula tudo.
 */
function filtrarEAtualizarDashboard(periodo) {
    
    // 1. Calcular a Data de Corte (Data Limite)
    const agora = new Date();
    let dias = 30;
    if (periodo === '90d') dias = 90;
    if (periodo === '1ano') dias = 365;
    
    const dataLimite = new Date();
    dataLimite.setDate(agora.getDate() - dias);

    // --- ATUALIZAR CVE (NVD) ---
    if (DADOS_COMPLETOS_CVE.length > 0) {
        const filtrados = DADOS_COMPLETOS_CVE.filter(x => x.data_publicacao >= dataLimite);
        
        // KPI Total
        const kpiVulnsEl = document.getElementById('kpi-novas-vulns');
        if(kpiVulnsEl) kpiVulnsEl.innerText = filtrados.length.toLocaleString('pt-BR');
        
        // Donut (Severidade)
        const sevCounts = { 'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0, 'NONE': 0 };
        filtrados.forEach(x => { if(sevCounts.hasOwnProperty(x.severidade)) sevCounts[x.severidade]++; });
        renderizarGraficoSeveridade(sevCounts);

        // Linha (Tendência)
        const timeline = {};
        const criticos = filtrados.filter(x => x.severidade === 'CRITICAL');
        criticos.sort((a, b) => a.data_publicacao - b.data_publicacao);
        criticos.forEach(x => {
            const dia = x.data_publicacao.toISOString().split('T')[0];
            timeline[dia] = (timeline[dia] || 0) + 1;
        });
        renderizarGraficoLinha(timeline);

        // Tipos de Vulnerabilidade
        const tiposCounts = {};
        filtrados.forEach(x => { 
            const t = x.tipo_falha || 'Outros'; 
            if (t !== 'Outros') tiposCounts[t] = (tiposCounts[t] || 0) + 1;
        });
        const topTipos = Object.entries(tiposCounts).sort((a,b) => b[1]-a[1]).slice(0, 6);
        renderizarGraficoVertical('tiposVulnChart', meuGraficoTiposVuln, Object.fromEntries(topTipos), 'Ocorrências');
    }

    // --- ATUALIZAR VAZAMENTOS (HIBP) ---
    if (DADOS_COMPLETOS_HIBP.length > 0) {
        const filtrados = DADOS_COMPLETOS_HIBP.filter(x => x.data_vazamento && x.data_vazamento >= dataLimite);
        
        // KPI Total Contas
        const totalContas = filtrados.reduce((acc, curr) => acc + (curr.contas_afetadas || 0), 0);
        let formatado = totalContas.toLocaleString('pt-BR');
        if (totalContas > 1000000) formatado = (totalContas/1000000).toFixed(1) + " Milhões";
        else if (totalContas > 1000) formatado = (totalContas/1000).toFixed(1) + " Mil";
        
        const kpiContasEl = document.getElementById('kpi-contas-vazadas');
        if(kpiContasEl) kpiContasEl.innerText = formatado;

        // Tabela Recentes
        const tabela = document.querySelector("#tabela-vazamentos tbody");
        if (tabela) {
            tabela.innerHTML = '';
            const topVaz = filtrados.sort((a,b) => b.contas_afetadas - a.contas_afetadas).slice(0, 5);
            
            if (topVaz.length === 0) {
                tabela.innerHTML = '<tr><td colspan="3">Sem vazamentos neste período.</td></tr>';
            } else {
                topVaz.forEach(v => {
                    const tr = document.createElement('tr');
                    const dataFmt = v.data_vazamento ? v.data_vazamento.toLocaleDateString('pt-BR') : "N/A";
                    tr.innerHTML = `
                        <td><strong>${v.nome_vazamento}</strong><br><span style="font-size:0.8em;color:var(--cor-texto-secundario)">${dataFmt}</span></td>
                        <td>${v.setor||'N/A'}</td>
                        <td>${(v.contas_afetadas||0).toLocaleString('pt-BR')}</td>`;
                    tabela.appendChild(tr);
                });
            }
        }
    }

    // --- ATUALIZAR OTX (Ameaças e Setores) ---
    if (DADOS_COMPLETOS_OTX.length > 0) {
        const filtrados = DADOS_COMPLETOS_OTX.filter(x => x.data_criacao && x.data_criacao >= dataLimite);
        
        const contAmeacas = {}, contSetores = {};
        filtrados.forEach(p => {
            if(p.ameacas) p.ameacas.forEach(t => contAmeacas[t.toLowerCase().trim()] = (contAmeacas[t.toLowerCase().trim()] || 0) + 1);
            if(p.setores) p.setores.forEach(s => contSetores[s.trim()] = (contSetores[s.trim()] || 0) + 1);
        });

        const getTop = (o) => Object.entries(o).sort((a,b)=>b[1]-a[1]).slice(0,5).reduce((r,[k,v])=>({...r,[k]:v}),{});
        const topA = getTop(contAmeacas), topS = getTop(contSetores);

        const kpiA = document.getElementById('kpi-ameaca-comum');
        if(kpiA) kpiA.innerText = Object.keys(topA)[0] || "N/A";
        
        const kpiS = document.getElementById('kpi-setor-atacado');
        if(kpiS) kpiS.innerText = Object.keys(topS)[0] || "N/A";
        
        renderizarGraficoBarras('setoresChart', meuGraficoSetores, topS, 'Setores Alvo');
    }

    // --- NOVO: ATUALIZAR PAÍSES (AbuseIPDB Dinâmico) ---
    if (DADOS_COMPLETOS_PAISES.length > 0) {
        // Filtro de data para AbuseIPDB (se houver campo data válido)
        const filtrados = DADOS_COMPLETOS_PAISES.filter(x => x.data_report && x.data_report >= dataLimite);
        
        const contPaises = {};
        filtrados.forEach(item => {
            if (item.pais) {
                const p = item.pais.trim();
                contPaises[p] = (contPaises[p] || 0) + 1;
            }
        });

        // Top 5 Países
        const topPaises = Object.entries(contPaises)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});

        renderizarGraficoBarras('paisesChart', meuGraficoPaises, topPaises, 'Top 5 Países Origem (IPs)');
    }
}


// --- 3. FUNÇÕES DE RENDERIZAÇÃO DE GRÁFICOS (Chart.js) ---

function renderizarGraficoBarras(canvasId, chartInstance, dados, label) {
    const canvasEl = document.getElementById(canvasId);
    if (!canvasEl) return;

    // Lógica para "sem dados"
    if (!dados || Object.keys(dados).length === 0) {
        // Aqui você poderia desenhar um texto no canvas dizendo "Sem dados"
        if (chartInstance) chartInstance.destroy();
        return;
    }

    const labels = Object.keys(dados);
    const dataPoints = Object.values(dados);
    
    const style = getComputedStyle(document.body);
    const corBarra = style.getPropertyValue('--cor-primaria');
    const corGrid = style.getPropertyValue('--cor-grafico-grid');
    const corTexto = style.getPropertyValue('--cor-texto-secundario');

    if (chartInstance) chartInstance.destroy();

    const config = {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: dataPoints,
                backgroundColor: `${corBarra}B3`,
                borderColor: corBarra,
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: corGrid }, ticks: { color: corTexto, font: { family: "'Roboto', sans-serif" } } },
                y: { grid: { display: false }, ticks: { color: corTexto, font: { family: "'Roboto', sans-serif" } } }
            }
        }
    };

    const chart = new Chart(canvasEl, config);
    
    // Atualizar referência global
    if(canvasId === 'setoresChart') meuGraficoSetores = chart;
    if(canvasId === 'paisesChart') meuGraficoPaises = chart;
}

function renderizarGraficoVertical(canvasId, chartInstance, dados, label) {
    const canvasEl = document.getElementById(canvasId);
    if (!canvasEl) return;

    if (!dados || Object.keys(dados).length === 0) return;

    const labels = Object.keys(dados);
    const dataPoints = Object.values(dados);
    
    const style = getComputedStyle(document.body);
    const corBarra = style.getPropertyValue('--cor-secundaria') || '#00c49f'; 
    const corGrid = style.getPropertyValue('--cor-grafico-grid');
    const corTexto = style.getPropertyValue('--cor-texto-secundario');

    if (meuGraficoTiposVuln) meuGraficoTiposVuln.destroy();

    meuGraficoTiposVuln = new Chart(canvasEl, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: dataPoints,
                backgroundColor: `${corBarra}B3`, 
                borderColor: corBarra,
                borderWidth: 1,
                borderRadius: 4
            }]
        },
        options: {
            indexAxis: 'x',
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { grid: { color: corGrid }, ticks: { color: corTexto } },
                x: { grid: { display: false }, ticks: { color: corTexto, font: { size: 10 } } }
            }
        }
    });
}

function renderizarGraficoSeveridade(dados) {
    const canvasEl = document.getElementById('donutChart');
    if (!canvasEl) return;

    const labels = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'NONE'];
    const dataPoints = labels.map(l => dados[l] || 0);

    const style = getComputedStyle(document.body);
    const colors = [
        style.getPropertyValue('--cor-perigo'),
        style.getPropertyValue('--cor-aviso'),
        style.getPropertyValue('--cor-primaria'),
        style.getPropertyValue('--cor-neutra'),
        '#808080'
    ];
    const corTexto = style.getPropertyValue('--cor-texto-secundario');
    const corBorda = style.getPropertyValue('--cor-fundo-card');

    if (meuGraficoDonut) meuGraficoDonut.destroy();

    meuGraficoDonut = new Chart(canvasEl, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: dataPoints,
                backgroundColor: colors,
                borderColor: corBorda,
                borderWidth: 4,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: { position: 'right', labels: { color: corTexto, font: { size: 12 }, boxWidth: 12 } }
            }
        }
    });
}

function renderizarGraficoLinha(dadosDiarios) {
    const canvasEl = document.getElementById('lineChart');
    if (!canvasEl) return; 

    const labels = Object.keys(dadosDiarios);
    const dataPoints = Object.values(dadosDiarios);
    const style = getComputedStyle(document.body);
    const corLinha = style.getPropertyValue('--cor-perigo');
    const corGrid = style.getPropertyValue('--cor-grafico-grid');
    const corTexto = style.getPropertyValue('--cor-texto-secundario');
    
    // Fallback seguro para cores
    const corSegura = corLinha || '#ff4d4f';
    let corFundo1 = corSegura + '80';
    let corFundo2 = corSegura + '00';
    if(corSegura.startsWith('#')) {
       corFundo1 = corSegura + '80'; 
       corFundo2 = corSegura + '00';
    }

    if (meuGraficoLinha) meuGraficoLinha.destroy();

    meuGraficoLinha = new Chart(canvasEl, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Críticas',
                data: dataPoints,
                fill: true,
                backgroundColor: (ctx) => {
                    const gradient = ctx.chart.ctx.createLinearGradient(0, 0, 0, 300);
                    try {
                        gradient.addColorStop(0, corFundo1);
                        gradient.addColorStop(1, corFundo2);
                    } catch(e) { return corSegura; }
                    return gradient;
                },
                borderColor: corSegura,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { type: 'time', time: { unit: 'week', tooltipFormat: 'dd/MM/yyyy' }, grid: { color: corGrid }, ticks: { color: corTexto } },
                y: { beginAtZero: true, grid: { color: corGrid }, ticks: { color: corTexto } }
            }
        }
    });
}

