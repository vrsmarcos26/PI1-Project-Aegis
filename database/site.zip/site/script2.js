// ARQUIVO DE SCRIPT 2 (script2.js)
// Contém toda a lógica do chatbot: JSON fallback, API do Gemini e UI handlers.

// VARIÁVEIS GLOBAIS NECESSÁRIAS
let knowledgeBase = [];

// Função utilitária para esperar (usada no backoff)
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

// Função para injetar mensagens no corpo do chat (Interface)
function appendMessage(sender, text) {
    const messages = document.getElementById('chatbot-messages');
    const msgDiv = document.createElement('div');
    
    msgDiv.classList.add('message', sender);
    // Permite que o texto do Gemini (que usa negrito Markdown) seja renderizado
    // Substitui **texto** por <strong>texto</strong>
    msgDiv.innerHTML = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>'); 
    messages.appendChild(msgDiv);
    messages.scrollTop = messages.scrollHeight; 
}

// 1. CARREGAMENTO DA BASE DE CONHECIMENTO LOCAL
async function loadKnowledgeBase() {
    // Acessa as configurações globais definidas em config.js e script.js
    if (typeof langConfig === 'undefined' || typeof idiomaAtual === 'undefined') {
        console.error("Erro: Variáveis globais 'langConfig' ou 'idiomaAtual' não definidas. Certifique-se de que config.js e script.js foram carregados ANTES de script2.js.");
        return;
    }
    const KNOWLEDGE_BASE_URL = langConfig[idiomaAtual].chatbot.KNOWLEDGE_BASE_URL;
    try {
        const response = await fetch(KNOWLEDGE_BASE_URL);
        knowledgeBase = await response.json();
        console.log("Base de conhecimento do chatbot carregada com sucesso.");
    } catch (error) {
        console.error("Erro ao carregar a base de conhecimento local:", error);
    }
}

// 2. BUSCA NA BASE DE CONHECIMENTO LOCAL
function getLocalAnswer(pergunta) {
    const perguntaLower = pergunta.toLowerCase();
    
    for (const item of knowledgeBase) {
        // Verifica se alguma palavra-chave da resposta está contida na pergunta do usuário
        if (item.palavras_chave.some(keyword => perguntaLower.includes(keyword.toLowerCase()))) {
            return item.resposta;
        }
    }
    return null;
}

// 3. FALLBACK PARA O GEMINI (com Repetição e Reforço de Segurança)
async function getGeminiSecurityAnswer(pergunta) {
    const { GEMINI_API_URL_FULL, SYSTEM_INSTRUCTION, ERROR_MESSAGE } = langConfig[idiomaAtual].chatbot;
    
    if (!GEMINI_API_URL_FULL.includes("?key=")) {
        console.error("ERRO: A chave da API do Gemini não foi definida na URL do 'config.js'.");
        return "Erro de configuração: A chave da API do Gemini está faltando na URL do 'config.js'. Por favor, insira sua chave.";
    }

    const MAX_RETRIES = 3;
    
    for (let i = 0; i < MAX_RETRIES; i++) {
        try {
            // Usa a URL completa (incluindo o "?key=SUA_CHAVE")
            const response = await fetch(GEMINI_API_URL_FULL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    model: "gemini-2.5-flash",
                    
                    // CORREÇÃO FINAL DA ESTRUTURA DO PAYLOAD
                    // O campo systemInstruction deve ser um objeto Content, não uma string.
                    systemInstruction: {
                        parts: [{
                            text: SYSTEM_INSTRUCTION
                        }]
                    },
                    
                    generationConfig: {
                        temperature: 0.7, 
                    },
                    
                    contents: [{ role: "user", parts: [{ text: pergunta }] }],
                })
            });

            if (response.ok) {
                const data = await response.json();
                
                if (data.candidates && data.candidates[0].content && data.candidates[0].content.parts[0].text) {
                     return data.candidates[0].content.parts[0].text;
                } else {
                     return "Sua consulta não pôde ser processada. Lembre-se, o foco é em cibersegurança e inteligência de ameaças.";
                }
            } else {
                // Tenta ler o corpo da resposta para capturar a mensagem de erro da API
                let errorMessage = `Status ${response.status}`;
                try {
                    const errorJson = await response.json();
                    if (errorJson.error && errorJson.error.message) {
                        errorMessage += `: ${errorJson.error.message}`;
                    } else {
                        errorMessage += `: ${JSON.stringify(errorJson)}`;
                    }
                } catch {
                    const errorText = await response.text();
                    errorMessage += `: ${errorText.substring(0, 100)}...`;
                }

                if (response.status === 429 && i < MAX_RETRIES - 1) {
                    // Erro de Limite de Taxa (429) -> Tenta novamente
                    const delay = Math.pow(2, i) * 1000;
                    await wait(delay);
                } else {
                    // Erro fatal (400, 403, 500)
                    console.error(`Erro de API Irrecuperável (Tentativa ${i + 1}/${MAX_RETRIES}):`, errorMessage);
                    throw new Error("API Error Logged.");
                }
            }

        } catch (error) {
            if (i === MAX_RETRIES - 1) {
                console.error("Tentativas de API esgotadas.", error);
                return ERROR_MESSAGE;
            }
            // Erro de rede/conexão: tenta novamente após o delay
            const delay = Math.pow(2, i) * 1000;
            await wait(delay);
        }
    }
    return ERROR_MESSAGE; // Fallback final
}

// 4. FUNÇÃO PRINCIPAL DE RESPOSTA (Gerencia JSON ou Gemini)
async function getChatbotResponse(pergunta) {
    // 1. Tenta a resposta local
    const localAnswer = getLocalAnswer(pergunta);
    if (localAnswer) {
        return localAnswer;
    }

    // 2. Se não encontrou, recorre ao Gemini
    return await getGeminiSecurityAnswer(pergunta);
}

// 5. FUNÇÃO QUE LIDA COM A INTERAÇÃO DO USUÁRIO
async function handleUserQuery() {
    const input = document.getElementById('chatbot-input');
    const query = input.value.trim();

    if (query === "") return;

    // 1. Exibir a pergunta do usuário
    appendMessage('user', query);
    input.value = ''; 

    // 2. Exibir mensagem de loading
    appendMessage('bot', langConfig[idiomaAtual].chatbot.LOADING_MESSAGE);
    const loadingMessage = document.querySelector('.chatbot-body .message:last-child');

    // 3. Obter a resposta e substituí-la
    const resposta = await getChatbotResponse(query);
    
    loadingMessage.innerHTML = resposta;
}

// 6. LÓGICA DE ABERTURA/FECHAMENTO E LISTENERS
document.addEventListener('DOMContentLoaded', () => {
    // Inicia o carregamento da base de conhecimento (depende de langConfig e idiomaAtual)
    loadKnowledgeBase(); 
    
    const toggleBtn = document.getElementById('chatbot-toggle');
    const closeBtn = document.getElementById('chatbot-close');
    const windowDiv = document.getElementById('chatbot-window');
    const sendBtn = document.getElementById('chatbot-send');
    const input = document.getElementById('chatbot-input');
    const welcomeMessage = document.getElementById('welcome-message');
    
    // Atualiza a mensagem de boas-vindas com o texto de config.js (após o carregamento do idioma)
    if (welcomeMessage && typeof langConfig !== 'undefined' && langConfig[idiomaAtual].chatbot) {
         welcomeMessage.innerHTML = langConfig[idiomaAtual].chatbot.WELCOME_MESSAGE;
    }


    if(toggleBtn && windowDiv) {
        toggleBtn.addEventListener('click', () => {
            windowDiv.classList.toggle('open');
            if (windowDiv.classList.contains('open')) {
                input.focus(); // Foca no input ao abrir
            }
        });
    }

    if(closeBtn && windowDiv) {
        closeBtn.addEventListener('click', () => {
            windowDiv.classList.remove('open');
        });
    }

    if(sendBtn) {
        sendBtn.addEventListener('click', handleUserQuery);
    }
    
    if(input) {
         // Permite enviar mensagem pressionando Enter
         input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault(); // Evita a quebra de linha no input
                handleUserQuery();
            }
         });
    }
});